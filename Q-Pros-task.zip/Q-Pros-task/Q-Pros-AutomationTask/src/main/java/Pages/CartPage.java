package Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

public class CartPage {
    public WebDriver webdriver;
    // create constractor
    public CartPage(WebDriver webdriver)
    {
        this.webdriver=webdriver;
    }


  public   By Delete_button =By.linkText("Delete");
    By Placeorder_button1 =By.xpath("//button[contains(text(),'Place Order')]");
    public void user_can_remove_added_item_from_cartpage()  {
        //  Thread.sleep(1500);
        WebDriverWait wait = new WebDriverWait(webdriver, Duration.ofSeconds(5));
        wait.until(ExpectedConditions.elementToBeClickable(Delete_button));

        webdriver.findElement(Delete_button).click();


    }
    public PlaceOrderPage Click_On_Placeorder_Button() {
        webdriver.findElement(Placeorder_button1).click();
        return new PlaceOrderPage(webdriver);
    }
}
