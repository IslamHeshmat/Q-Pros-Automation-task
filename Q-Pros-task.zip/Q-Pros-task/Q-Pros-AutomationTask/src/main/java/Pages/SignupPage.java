package Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

public class SignupPage {
    private WebDriver webdriver;
    // create constractor
    public SignupPage(WebDriver webdriver)
    {
        this.webdriver=webdriver;
    }
    By Username_testbox =By.id("sign-username");
    By Password_testbox =By.id("sign-password");
    By Signup_button1 =By.xpath("//button[@onclick='register()']");
    public void Singup (String username, String password)  {

        webdriver.findElement(Username_testbox).isDisplayed();
        webdriver.findElement(Password_testbox).isDisplayed();
        webdriver.findElement(Signup_button1).isEnabled();
        webdriver.findElement(Username_testbox).sendKeys(username);
        webdriver.findElement(Password_testbox).sendKeys(password);
        webdriver.findElement(Signup_button1).click();
        WebDriverWait wait = new WebDriverWait(webdriver, Duration.ofSeconds(5));
        wait.until(ExpectedConditions.alertIsPresent());
        webdriver.switchTo().alert().accept();
    }

}
