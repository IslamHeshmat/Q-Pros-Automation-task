package Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;
import java.util.concurrent.TimeUnit;

public class PlaceOrderPage {
    private WebDriver webdriver;
    // create constractor
    public PlaceOrderPage(WebDriver webdriver)
    {
        this.webdriver=webdriver;
    }

    By name_testbox =By.id("name");
    By country_testbox =By.id("country");
    By city_testbox =By.id("city");
    By creditcard_testbox =By.id("card");
    By month_testbox =By.id("month");
    By year_testbox =By.id("year");
    By Purchase_button =By.xpath("//button[contains(text(),'Purchase')]");


    public ConfirmPaymentPop_up user_can_fill_data_to_Purchase(String name, String country, String city, String creditcard, String month, String year)
    {
        webdriver.findElement(name_testbox).sendKeys(name);
        webdriver.findElement(country_testbox).sendKeys(country);
        webdriver.findElement(city_testbox).sendKeys(city);
        webdriver.findElement(creditcard_testbox).sendKeys(creditcard);
        webdriver.findElement(month_testbox).sendKeys(month);
        webdriver.findElement(year_testbox).sendKeys(year);
        webdriver.findElement(Purchase_button).click();
        return new ConfirmPaymentPop_up(webdriver);
    }
}
