package Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

public class ProductPage {
    private WebDriver webdriver;
    // create constractor
    public ProductPage(WebDriver webdriver)
    {
        this.webdriver=webdriver;
    }

        By add_to_cart_button =By.xpath(" //a[@onclick='addToCart(8)']");
         By Cart_Button = By.id("cartur");

    public void user_can_add_product_to_cart() throws InterruptedException {
        webdriver.findElement(add_to_cart_button).click();
      //  Thread.sleep(1500);
        WebDriverWait wait = new WebDriverWait(webdriver, Duration.ofSeconds(5));
        wait.until(ExpectedConditions.alertIsPresent());
        webdriver.switchTo().alert().accept();

    }
    public CartPage user_can_navigate_to_cartpage() throws InterruptedException {
        WebDriverWait wait = new WebDriverWait(webdriver, Duration.ofSeconds(5));
        wait.until(ExpectedConditions.visibilityOfElementLocated(Cart_Button));
        webdriver.findElement(Cart_Button).click();
         return new CartPage(webdriver);
    }
}
