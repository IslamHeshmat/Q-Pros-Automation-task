package Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class LoginPage {
    private WebDriver webdriver;
    // create constractor
    public LoginPage(WebDriver webdriver)
    {
        this.webdriver=webdriver;
    }
    By Username_textbox =By.id("loginusername");
    By Password_textbox =By.id("loginpassword");
    By Login_button1 =By.xpath("//button[@onclick='logIn()']");
    public void Login (String username, String password) throws InterruptedException {

        webdriver.findElement(Username_textbox).isDisplayed();
        webdriver.findElement(Username_textbox).sendKeys(username);
        webdriver.findElement(Password_textbox).isDisplayed();
        webdriver.findElement(Password_textbox).sendKeys(password);
        webdriver.findElement(Login_button1).isEnabled();
        webdriver.findElement(Login_button1).click();
    }
}
