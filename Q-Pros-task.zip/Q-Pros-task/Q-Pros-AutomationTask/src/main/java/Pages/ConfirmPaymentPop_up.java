package Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;

public class ConfirmPaymentPop_up {
    public WebDriver webdriver;
    // create constractor
    public ConfirmPaymentPop_up(WebDriver webdriver)
    {
        this.webdriver=webdriver;
    }
    By ok_button = By.cssSelector(".confirm.btn.btn-lg.btn-primary");


    public void user_can_confirm_payment(){
        webdriver.findElement(ok_button).click();
    }
}
