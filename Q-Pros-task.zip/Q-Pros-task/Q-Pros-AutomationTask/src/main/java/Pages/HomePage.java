package Pages;


import com.shaft.driver.SHAFT;
import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;
import java.util.List;

public class HomePage {
    public WebDriver webdriver;
    // create constractor
    public HomePage(WebDriver webdriver)
    {
        this.webdriver=webdriver;
    }
    By Singup_button = By.id("signin2");
    By Login_button =By.id("login2");

    By laptops_list =By.xpath("//a[contains(text(),'Laptops')]");
    By product =By.linkText("Sony vaio i5");
    public By logout_button =By.id("logout2");


    public SignupPage Click_on_the_singup_button()  {

        webdriver.findElement(Singup_button).click();
        return new SignupPage(webdriver);
    }

    public LoginPage Click_on_the_loginpage_button()  {

        webdriver.findElement(Login_button).click();
        return new LoginPage(webdriver);
    }
    public void Click_on_the_logoutpage_button() throws InterruptedException {
      //  Thread.sleep(1500);
        WebDriverWait wait = new WebDriverWait(webdriver, Duration.ofSeconds(5));
        wait.until(ExpectedConditions.visibilityOfElementLocated(logout_button));
        webdriver.findElement(logout_button).isEnabled();
        webdriver.findElement(logout_button).click();

    }
    public void check_categorylist_size() throws InterruptedException {
        Thread.sleep(1500);
        webdriver.findElement(laptops_list).isDisplayed();
        webdriver.findElement(laptops_list).click();
        List<WebElement> elements = webdriver.findElements(By.xpath("//img[@class='card-img-top img-fluid']"));
        System.out.println("Number of elements:" +elements.size());
        boolean size = elements.isEmpty();
        if (size == true)
        {
            System.out.println("the list is empty");
        }
        else
            System.out.println("the list is not empty");
    }
    public ProductPage user_can_select_product()
    {
        webdriver.findElement(product).click();
        return new ProductPage(webdriver);
    }
}