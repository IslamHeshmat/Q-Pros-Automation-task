package tests;
import Pages.SignupPage;
import data.LoadProperties;
import org.testng.annotations.Test;

public class Test_Register extends BaseTest{
    protected SignupPage SignpageupObject;
    String username= LoadProperties.userData.getProperty("username");
    String password=LoadProperties.userData.getProperty("password");

     @Test
     public void Verify_That_guest_user_can_register()  {
         SignpageupObject = homepageobject.Click_on_the_singup_button();
         SignpageupObject.Singup(username,password);
     }
}
