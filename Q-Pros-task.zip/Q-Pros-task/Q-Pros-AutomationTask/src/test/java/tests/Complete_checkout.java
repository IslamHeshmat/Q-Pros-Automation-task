package tests;




import Pages.*;
import data.LoadProperties;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.Test;

public class Complete_checkout extends BaseTest {

    protected LoginPage LoginpageObject;
    protected ProductPage  Productpageobject;
    protected CartPage Cartpageobject;

    protected PlaceOrderPage PlaceOrderobject;
    protected ConfirmPaymentPop_up  ConfirmPaymentPop_upobject;
    String username= LoadProperties.userData.getProperty("username");
    String password=LoadProperties.userData.getProperty("password");

    //********************************************************************************************************************************************************
    @Test
    public void Check_That_Register_user_can_login() throws InterruptedException {
        LoginpageObject = homepageobject.Click_on_the_loginpage_button();
        LoginpageObject.Login(username,password);
        //assert that logout button appears after login
        WebElement islogout_buttonDisplayed;
        islogout_buttonDisplayed = homepageobject.webdriver.findElement(homepageobject.logout_button);
        Assert.assertTrue(islogout_buttonDisplayed.isEnabled());
    }
    //********************************************************************************************************************************************************
    @Test(dependsOnMethods={"Check_That_Register_user_can_login"})
    public void verfiy_that_the_laptoplist_has_items() throws InterruptedException {
        homepageobject.check_categorylist_size();
    }
    //********************************************************************************************************************************************************
    @Test(dependsOnMethods={"verfiy_that_the_laptoplist_has_items"})
    public void Verfiy_that_user_can_select_product() throws InterruptedException {
        Productpageobject = homepageobject.user_can_select_product();
    }
    //********************************************************************************************************************************************************
    @Test(dependsOnMethods={"Verfiy_that_user_can_select_product"})
    public void Verfiy_That_user_can_add_product_to_cart() throws InterruptedException {
        Productpageobject.user_can_add_product_to_cart();
    }
    //********************************************************************************************************************************************************
     @Test(dependsOnMethods={"Verfiy_That_user_can_add_product_to_cart"})
    public void Verfiy_That_User_Can_navigate_to_cartpage() throws InterruptedException {
         Cartpageobject=Productpageobject.user_can_navigate_to_cartpage();
    }
    //********************************************************************************************************************************************************
    @Test(dependsOnMethods={"Verfiy_That_User_Can_navigate_to_cartpage"})
    public void Verfiy_That_User_can_placeorder() throws InterruptedException {

        PlaceOrderobject=Cartpageobject.Click_On_Placeorder_Button();
    }
    //********************************************************************************************************************************************************
    @Test(dependsOnMethods={"Verfiy_That_User_can_placeorder"})
    public void Verfiy_That_User_can_fill_data_placeorder() throws InterruptedException {

        ConfirmPaymentPop_upobject=  PlaceOrderobject.user_can_fill_data_to_Purchase("sdsad","Egypt","cairo","sds","5","5");
        ConfirmPaymentPop_upobject.user_can_confirm_payment();

        //test case assertion
        boolean isThankyouforyourpurchaseDisplayed;
        isThankyouforyourpurchaseDisplayed = ConfirmPaymentPop_upobject.webdriver.findElement(By.xpath("//h2[normalize-space()='Thank you for your purchase!']")).isDisplayed();
        Assert.assertTrue(isThankyouforyourpurchaseDisplayed);


    }

   /* @Test(priority = 8)
    public void Verfiy_That_User_can_remove_item_from_cart() throws InterruptedException {
        Cartpageobject.user_can_remove_added_item_from_cartpage();
    }*/
}