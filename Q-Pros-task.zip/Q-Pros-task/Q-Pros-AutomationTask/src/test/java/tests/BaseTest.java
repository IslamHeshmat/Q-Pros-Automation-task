package tests;


import Pages.HomePage;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;

import java.time.Duration;


public class BaseTest {

    public static WebDriver webdriver;
    protected HomePage homepageobject;

    @BeforeClass
    public void setUp(){

        ChromeDriver webdriver = new ChromeDriver();
        webdriver.manage().window().maximize();
        webdriver.navigate().to("https://www.demoblaze.com/");
        homepageobject= new HomePage(webdriver);
        webdriver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));

    }
    @AfterClass
    public void tearDown()
    {
        homepageobject.webdriver.close();
    }
}