package tests;
import Pages.*;
import data.LoadProperties;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.Test;


import java.util.List;



public class Test_Add_Remove_cart_item extends BaseTest {

    protected LoginPage LoginpageObject;
    protected ProductPage Productpageobject;
    protected CartPage Cartpageobject;

    protected PlaceOrderPage PlaceOrderobject;
    protected ConfirmPaymentPop_up ConfirmPaymentPop_upobject;
    String username = LoadProperties.userData.getProperty("username");
    String password = LoadProperties.userData.getProperty("password");

//********************************************************************************************************************************************************
    @Test
    public void Check_That_Register_user_can_login() throws InterruptedException {
        LoginpageObject = homepageobject.Click_on_the_loginpage_button();
        LoginpageObject.Login(username, password);
        //assert that logout button appears after login
        WebElement islogout_buttonDisplayed;
        islogout_buttonDisplayed = homepageobject.webdriver.findElement(homepageobject.logout_button);
        Assert.assertTrue(islogout_buttonDisplayed.isEnabled());

    }
    //********************************************************************************************************************************************************
    @Test(dependsOnMethods = {"Check_That_Register_user_can_login"})
    public void verfiy_that_the_laptoplist_has_items() throws InterruptedException {
        homepageobject.check_categorylist_size();
    }
    //********************************************************************************************************************************************************
    @Test(dependsOnMethods = {"verfiy_that_the_laptoplist_has_items"})
    public void Verfiy_that_user_can_select_product() throws InterruptedException {
        Productpageobject = homepageobject.user_can_select_product();
    }
    //********************************************************************************************************************************************************
    @Test(dependsOnMethods = {"Verfiy_that_user_can_select_product"})
    public void Verfiy_That_user_can_add_product_to_cart() throws InterruptedException {
        Productpageobject.user_can_add_product_to_cart();
    }
    //********************************************************************************************************************************************************
    @Test(dependsOnMethods = {"Verfiy_That_user_can_add_product_to_cart"})
    public void Verfiy_That_User_Can_navigate_to_cartpage() throws InterruptedException {
        Cartpageobject = Productpageobject.user_can_navigate_to_cartpage();
        WebElement is_Delete_buttonDisplayed;
        is_Delete_buttonDisplayed = homepageobject.webdriver.findElement(Cartpageobject.Delete_button);
        Assert.assertTrue(is_Delete_buttonDisplayed.isEnabled());
    }
    //********************************************************************************************************************************************************
   @Test(dependsOnMethods = {"Verfiy_That_User_Can_navigate_to_cartpage"})
    public void Verfiy_That_User_can_remove_item_from_cart() throws InterruptedException {
        Cartpageobject.user_can_remove_added_item_from_cartpage();
        //assert there is no any exist cell in the table which is means the table has no items
    Thread.sleep(1000);
   List<WebElement>  Cells=Cartpageobject.webdriver.findElements(By.xpath("//table[@class='table table-bordered table-hover table-striped']//td"));
  // System.out.println(Cells.size());
       Assert.assertTrue(Cells.isEmpty());

   }
    }